#include "dependencies.h"


void exportImage(int WIDTH, int HEIGTH, char* output_path);