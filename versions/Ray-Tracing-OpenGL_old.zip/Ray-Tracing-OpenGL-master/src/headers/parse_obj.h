#include "dependencies.h"

void parse_obj_file(string obj_file_path, vector<glm::vec3> &vertices, vector<glm::vec3> &normals);